/*
 * dataparser.h
 *
 *  Created on: Dec 2, 2022
 *      Author: sup3r
 */

#ifndef INC_DATAPARSER_H_
#define INC_DATAPARSER_H_

void parseCommand();
void clearCommand();

#endif
